import PrimaryDetailedBody from "../components/JknowsBody";
import Enzyme, { shallow } from 'enzyme'

it('test1',()=>{
    const detailedBody = shallow(<PrimaryDetailedBody/>)
    expect()
})